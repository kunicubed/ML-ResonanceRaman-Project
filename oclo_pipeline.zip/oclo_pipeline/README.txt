Layout
  pipeline.py            orchestrator (all stages)
  run_linux.sh / run_mac.sh / run_windows.ps1 (+ .bat)   set ORCA / JULIA and call pipeline.py
  scripts/               your scripts (gaussian.py takes the csv as argument, scan_oclo.py reads $ORCA)
  qd/                    QD-engine julia scripts
  inputs/                ground.yml, excited.yml

Stages (in order)
  opt scan fit levels ground excited spectra plots wf regression compare

Usage
  ./run_mac.sh --setup                         install python + julia packages
  ./run_mac.sh                                 gas run, all stages
  ./run_mac.sh --runs gas cyclohexane          both runs, then the overlay comparison
  ./run_mac.sh --stages fit levels             only these stages
  ./run_mac.sh --from spectra                  this stage onwards
  ./run_mac.sh --final-states 2 3 4 5 6 7      eigenstate indices for Raman
  ./run_mac.sh --force                         redo stages whose outputs exist
  ./run_mac.sh --dry-run                       print commands only

Windows: .\run_windows.ps1 [same options]; set ORCA (e.g. C:\ORCA\orca.exe) and make sure julia is on PATH.
Outputs: runs/<gas|cyclohexane>/{fit,ground,excited,wf,figures}, runs/compare
