#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export ORCA="${ORCA:-$HOME/orca/orca}"
export JULIA="${JULIA:-julia}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
exec "${PYTHON:-python3}" pipeline.py "$@"
