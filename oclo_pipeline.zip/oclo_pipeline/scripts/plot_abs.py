# usage: python plot_abs.py spectrum_550fs.txt [out.png]
# columns: 1 energy (cm-1), 2 Hanning window, 3 Gaussian lineshape, 4 Kubo lineshape
import sys, numpy as np, matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator

f = sys.argv[1] if len(sys.argv) > 1 else "spectrum_550fs.txt"
out = sys.argv[2] if len(sys.argv) > 2 else "absorption.png"
d = np.loadtxt(f, comments="#")
E, han, gau = d[:, 0], d[:, 1], d[:, 2]
han, gau = han/han.max(), gau/gau.max()

plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(7, 3.8), dpi=200)
ax.fill_between(E, han, color="#5e81b5", alpha=0.18, lw=0)
ax.plot(E, han, color="#2f5597", lw=1.4, label="Hanning window")
ax.plot(E, gau, color="#e19c24", lw=0.9, alpha=0.9, label="Gaussian lineshape")
ax.set_xlim(22000, 38000); ax.set_ylim(0, 1.05)
ax.set_xlabel(r"Energy (cm$^{-1}$)"); ax.set_ylabel("Normalised intensity")
ax.xaxis.set_minor_locator(AutoMinorLocator()); ax.yaxis.set_minor_locator(AutoMinorLocator())
ax.legend(frameon=False, loc="upper right")
fig.tight_layout(); fig.savefig(out); print("saved", out)
