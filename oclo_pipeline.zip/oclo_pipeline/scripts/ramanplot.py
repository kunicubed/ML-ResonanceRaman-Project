import glob, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

LASERS = [28135.0]        # cm^-1 (368.9 nm, 360.3 nm)
FWHM = 20.0                          # Lorentzian broadening, cm^-1
# final state index -> (label, shift cm^-1)
STATES = {2: ("v2", 454.9), 3: ("v1", 954.3), 4: ("2v2", 916.0),
          5: ("2v1", 1903.1), 6: ("3v1", 2852.2), 7: ("v1+v2", 1406.4)}
EXP = {"v2": 452, "v1": 944, "2v2": 897, "v1+v2": 1386, "2v1": 1884, "3v1": 2811}

def load(fn):
    d = np.loadtxt(fn, comments="#")   # 7 cols: wn, Hann, Gauss, Kubo, Hann raw, Gauss raw, Kubo raw
    return d[:, 0], d[:, 5]            # raw Gauss column

data = {}
for n, (lab, shift) in STATES.items():
    fn = f"resRaman_1{n}.txt"
    if glob.glob(fn):
        data[n] = load(fn)
    else:
        print("missing", fn)

x = np.linspace(0, 3200, 4000)
fig, axs = plt.subplots(len(LASERS), 1, figsize=(8, 3.5 * len(LASERS)), sharex=True)
for ax, laser in zip(np.atleast_1d(axs), LASERS):
    sticks = []
    for n, (wn, y) in data.items():
        lab, shift = STATES[n]
        I = np.interp(laser, wn, y) * (laser - shift) ** 3
        sticks.append((lab, shift, I))
    if not sticks:
        continue
    m = max(s[2] for s in sticks)
    spec = np.zeros_like(x)
    for lab, shift, I in sticks:
        I /= m
        ax.vlines(shift, 0, I, color="C0")
        ax.text(shift, I, lab, ha="center", va="bottom", fontsize=8)
        spec += I * (FWHM / 2) ** 2 / ((x - shift) ** 2 + (FWHM / 2) ** 2)
    ax.plot(x, spec, "k", lw=1)
    for lab, e in EXP.items():
        ax.axvline(e, color="r", ls=":", lw=0.6)
    ax.set_title(f"Laser {laser:.0f} cm$^{{-1}}$ ({1e7/laser:.1f} nm)")
    ax.set_ylabel("Intensity (norm.)")
    ax.set_ylim(0, 1.2)
axs[-1].set_xlabel("Raman shift (cm$^{-1}$)") if len(LASERS) > 1 else None
plt.tight_layout()
plt.savefig("raman_shift.png", dpi=200)
print("saved raman_shift.png")
