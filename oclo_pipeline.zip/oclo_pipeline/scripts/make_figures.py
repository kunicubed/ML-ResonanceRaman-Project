】
import glob, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# ---------------- settings ----------------
LASER = 28135.0               # laser energy for the spectrum panel, cm^-1
EMIN, EMAX = 25000, 31000       # laser-energy range for profiles / map
SHIFT_MAX = 3200                # Raman-shift range
FWHM_SHIFT = 30.0               # Lorentzian width in the shift direction (spectrum + map)
PER_PANEL = False               # True: scale each profile panel to its own maximum
STATES = {2: (r"$\nu_2$", 454.9), 3: (r"$\nu_1$", 954.3), 4: (r"$2\nu_2$", 916.0),
          7: (r"$\nu_1+\nu_2$", 1406.4), 5: (r"$2\nu_1$", 1903.1), 6: (r"$3\nu_1$", 2852.2)}

plt.rcParams.update({"font.family": "serif", "mathtext.fontset": "cm", "font.size": 11,
                     "xtick.direction": "in", "ytick.direction": "in",
                     "xtick.top": True, "ytick.right": True, "axes.linewidth": 1.0})

data = {}
for n, (lab, shift) in STATES.items():
    fn = f"resRaman_1{n}.txt"
    if os.path.exists(fn):
        d = np.loadtxt(fn, comments="#")
        data[n] = (d[:, 0], d[:, 5] * (d[:, 0] - shift) ** 3)   # (laser - shift)^3 factor
    else:
        print("missing", fn)
if not data:
    raise SystemExit("no resRaman files found")
gmax = max(y[(x > EMIN) & (x < EMAX)].max() for x, y in data.values())

# ---------------- Figure 1: excitation profiles ----------------
n = len(data); ncol = 3; nrow = int(np.ceil(n / ncol))
fig, axs = plt.subplots(nrow, ncol, figsize=(3.2 * ncol, 2.4 * nrow), sharex=True, sharey=not PER_PANEL, squeeze=False)
for ax, (k, (x, y)) in zip(axs.ravel(), data.items()):
    m = y[(x > EMIN) & (x < EMAX)].max() if PER_PANEL else gmax
    ax.plot(x, y / m, "k", lw=1.1)
    ax.axvline(LASER, color="r", ls="--", lw=0.8)
    ax.text(0.04, 0.88, f"{STATES[k][0]} $\\leftarrow$ (0,0)", transform=ax.transAxes)
    ax.set_xlim(EMIN, EMAX); ax.set_ylim(0, 1.15)
    ax.set_xticks(np.arange(np.ceil(EMIN/2000)*2000, EMAX, 2000))
for ax in axs.ravel()[n:]: ax.axis("off")
for ax in axs[-1]: ax.set_xlabel(r"$\tilde{\nu}_I$ (cm$^{-1}$)")
for ax in axs[:, 0]: ax.set_ylabel("Scaled intensity")
fig.tight_layout(); fig.savefig("fig_profiles.png", dpi=300); plt.close(fig)

# ---------------- Figure 2: spectrum (a) + 2D map (b) ----------------
red = LinearSegmentedColormap.from_list("whred", ["white", "#f4a38c", "#e8321f", "#8b1a10"])
def lor(x, x0, w): return (w / 2) ** 2 / ((x - x0) ** 2 + (w / 2) ** 2)
shifts = np.linspace(0, SHIFT_MAX, 1500)
lasers = np.linspace(EMIN, EMAX, 400)
Z = np.zeros((lasers.size, shifts.size))
for k, (x, y) in data.items():
    prof = np.interp(lasers, x, y) / gmax
    Z += prof[:, None] * lor(shifts[None, :], STATES[k][1], FWHM_SHIFT)
Z /= Z.max()

fig = plt.figure(figsize=(6.4, 7.0))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 2.2], width_ratios=[1, 0.04], hspace=0.08, wspace=0.05)
axa = fig.add_subplot(gs[0, 0]); axb = fig.add_subplot(gs[1, 0], sharex=axa); cax = fig.add_subplot(gs[1, 1])
spec = Z[np.abs(lasers - LASER).argmin()]
axa.plot(shifts, spec / spec.max(), "k", lw=1.1, label="Calculation")
for k, (lab, sh) in STATES.items():
    if k in data:
        i = spec[np.abs(shifts - sh).argmin()] / spec.max()
        axa.annotate(lab, (sh, i), xytext=(0, 4), textcoords="offset points", ha="center", fontsize=9)
if os.path.exists("experiment.csv"):
    e = np.loadtxt("experiment.csv", delimiter=",", comments="#")
    axa.plot(e[:, 0], e[:, 1] / e[:, 1].max(), "r--", lw=1.0, label="Experiment")
axa.legend(frameon=False, loc="upper right")
axa.set_ylabel("Scaled intensity"); axa.set_ylim(0, 1.25); axa.tick_params(labelbottom=False)
axa.text(0.02, 0.88, "(a)", transform=axa.transAxes)
im = axb.pcolormesh(shifts, lasers, Z, cmap=red, shading="auto", vmin=0, vmax=1)
axb.axhline(LASER, color="k", ls=":", lw=0.7)
axb.set_xlabel(r"$\tilde{\nu}_I-\tilde{\nu}_S$ (cm$^{-1}$)"); axb.set_ylabel(r"$\tilde{\nu}_I$ (cm$^{-1}$)")
axb.set_xlim(0, SHIFT_MAX); axb.text(0.02, 0.94, "(b)", transform=axb.transAxes)
cb = fig.colorbar(im, cax=cax); cb.set_label("Scaled intensity")
fig.savefig("fig_map.png", dpi=300, bbox_inches="tight"); plt.close(fig)
print("saved fig_profiles.png, fig_map.png")
