import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import eigsh
from scipy.special import eval_hermite, factorial

CM = 219474.63
WS, WB = 964.5/CM, 455.4/CM            # hartree, same as the export script
data = np.loadtxt("pot_ground.dat")     # columns: Qs, Qb, V(hartree); Qs slowest
xs, ys = np.unique(data[:,0]), np.unique(data[:,1])
nx, ny = len(xs), len(ys)
dx, dy = xs[1]-xs[0], ys[1]-ys[0]
V = data[:,2].reshape(nx, ny)

def d2(n, h):
    return sp.diags([1, -2, 1], [-1, 0, 1], shape=(n, n)) / h**2

T = -0.5 * (sp.kron(d2(nx, dx), sp.identity(ny)) + sp.kron(sp.identity(nx), d2(ny, dy)))   # mass = 1 m_e
H = (T + sp.diags(V.ravel())).tocsc()
E, psi = eigsh(H, k=20, which="SA")
order = np.argsort(E); E, psi = E[order], psi[:, order]

def ho(n, w, q):
    return (w/np.pi)**0.25 / np.sqrt(2.0**n * factorial(n)) * eval_hermite(n, np.sqrt(w)*q) * np.exp(-w*q**2/2)

basis = {}
for ns in range(5):
    for nb in range(5):
        b = np.outer(ho(ns, WS, xs), ho(nb, WB, ys)).ravel()
        basis[(ns, nb)] = b / np.linalg.norm(b)

print(f"{'idx':>3} {'E (cm-1)':>10} {'E-E0':>8}  best (n_stretch, n_bend)  overlap^2")
for i in range(len(E)):
    v = psi[:, i]
    ov = {k: (b @ v)**2 for k, b in basis.items()}
    k = max(ov, key=ov.get)
    print(f"{i:>3} {E[i]*CM:10.1f} {(E[i]-E[0])*CM:8.1f}  {k}  {ov[k]:.2f}")
