import glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

LASERS = [27100.0, 27750.0]      # experimental laser energies, cm^-1
XMIN, XMAX = 24000, 32000
# final state index -> (label, shift cm^-1)
STATES = {2: ("v2", 454.9), 3: ("v1", 954.3), 4: ("2v2", 916.0),
          5: ("2v1", 1903.1), 6: ("3v1", 2852.2), 7: ("v1+v2", 1406.4)}

fig, ax = plt.subplots(figsize=(9, 4.5))
curves = {}
for n, (lab, shift) in STATES.items():
    fn = f"resRaman_1{n}.txt"
    if not glob.glob(fn):
        print("missing", fn); continue
    d = np.loadtxt(fn, comments="#")
    wn, y = d[:, 0], d[:, 5]                 # raw Gauss column
    curves[lab] = (wn, y * (wn - shift) ** 3)  # (laser - shift)^3 factor
m = max(c[1][(c[0] > XMIN) & (c[0] < XMAX)].max() for c in curves.values())
for lab, (wn, y) in curves.items():
    ax.plot(wn, y / m, label=lab)
for L in LASERS:
    ax.axvline(L, color="k", ls="--", lw=0.8)
ax.set_xlim(XMIN, XMAX)
ax.set_xlabel("Laser energy (cm$^{-1}$)")
ax.set_ylabel("Raman intensity (norm.)")
ax.legend()
plt.tight_layout()
plt.savefig("raman_profiles.png", dpi=200)
print("saved raman_profiles.png")
