
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

CYC, GAS = sys.argv[1], sys.argv[2]
LASER_NM = float(sys.argv[3]) if len(sys.argv) > 3 else 368.9
LASER = 1e7 / LASER_NM
FWHM, ETA, NOISE, SEED = 14.0, 0.35, 0.008, 5
EMBED = "eNot1n9YU9cZB/BQbFZQLDUVBEefbCi4bFgVHFva3IAclhYEikvHIz+02Vih6MKTFsE+MBSENhaEQqXFgaCxsVAoaCoTCjaalQA1NS0UKjUOCjY2CoLFxoFgl3zf5J/Pc3POfc97znnvuXe46lLUj5HmZ6f8Pou6/VqHhK8xQqFoAIp1l6MmtWslcvEVmG34Eh6OGYpSniqSnBocRr8LyVfhnazrUS/lmiUec2NRrWVrucD8CShx/x4mld2EKsEtx7gJkvK6KXg6cCaqWfDCsxdb7kbxHL9vQ+/h+qduO1zO5mGQ6QHyjZA/xHWIksecinVuUGZ/BMrFy5izn6LwUZht4MMC/mNoPxzjAY9WeMKTg8thm48X7EleCQcaHocjE95wMmgVnM0SwKW2J6Hn3GroG+4L1+WvgVv0flDqvhZul/0SJpUFwHTzU1AlEMIDSb+C5XW/hsfGAuH7gevh2Ywg+GlLMDTNbICjoSJozfstc67fXPfvII+3EXqxp6G/ehMMNm2GYd6hcJs8DCbUbkWcVMvvcZ0h/AOuc9L/CIuaxFjHyqlnYP0mCWzO4ZhzH891SpmzLi4tRsArEduYsy4sJVGOazfO1s/YzfINnH3Fn9isj5pzT5Sxvtg+qXfNcywwRhYRMPo8FAXEsiMbjkvDFdvZkfcqOKaNYxnMJtlhi0e83SEvsFxVnWSvKhHj5HXswPgl839mzvqskrwIG4v+gvxae5Ngl8dOaIxLhkNVKeg3PpyK+6f9diHuQtpuRs/DS8xZzwKrAgpFf0MeIcp0zEes+ztz1rPM/jJLT0vl5OJM9sEP/Zyi8BWmic6VZhuyHOt4UFrA3wsPx/wD8z5aoWTr923jTg5ms1ffWsm1+agQvyf5VYw70PAa8hiZyMH8JoNykd9sVh5catsPPedeR7tveD7uX5dfgHhb9P9kMSs0nNT9ADuUaOO0gQfZWX2BtLX3IPLQZRTBLo9iJjUucvqWYsc86jhj3CHH+Fs508whxBmqKsF8R0NLkdf4cCnysua9gXGn/d6Ec93kQpoaefF4h7GufA3pxd6CAivpry6DQlE59iHYRIYoj8Aw7wq0i3UViBcpr0R8mb2S/SY1gYuvfZup73U71rsKpliqUFeKwmr0yxS+g/uVBnJf+lGYz69B/OImUh3zrqueyZqK91x1XYv+mkGyOecY8mj3+Rfs6CR7kuuwHobFOqzTQEO9c985c8Rx1MHIxHG2OmCn1FLSwJ6+XiKdDGqEtv5Gdm1+o3Q26wQzWoYdz8NJ1M9S20msu3uiBvE85zTYV++aU1h/3/D3YcAouS5fC0UBp9Fvs/406jJc8QHWg3NvQlymbUJesbJmmGhrRv0llX2I/rtCWhAn3dyC+exRtUKV4CO4v4MsTGrD+pbOk2V17bBacgbttWNnkEdj0VnMQxuow/itvTpnP06X8TEzHWjiujzOsec3SqX6lnPsq6q9UmNcB6u+nC01zZBDVf9GXY6Gnsf+jg+fx3NjzetE3tN+XXju5rq7MN5C2icYn8frRj58TTf2x4v1uOquB/vqr76Ac0wo+hQGm8gQpd51Hl6EYh0ZKb8EZXYyvtYA5eL/wBQLqSj8DHEyhb1QaSD3pRthPr8PFjf1ob86ph9WTpE1FQOwftPnUDNINudchu0+JtjRSfYkfwENi+RAwxVojjDDkQnSUvIlnAz6Ctr6ydmsQWhfMQSX2oaQn3vi1673GeldM+x6r43AgNER1/vtGygKuAo3669ifcMVo5Bz/xYyLRkru4Z+ibZrrvefBf/vCrkO083kHtV/oUowBvd3jGH/CpPGYek8WVb3HayWTMDasQnXeT+JfdcG3oCtvTdQD7qM72GXhxV1om+xot6NcTdR/6aZm3hehqp+wDk4GmpDnY4P29h4vZvUmncLTvvdZsLBGUfd3Ub/hbQp1DmPN43nla+ZRlwvdgcKrHcwrr96BgpFs8gr2DSLfEOUd2GY94+Yr1hHRsrnoMxOxtfeY/Qd9hNMsZCKQjvMFN53nXf3Xefd/1zn3Twsbpp3nXcLrvNuwXXePXCdd4tQM7joep8vwXafh7Cjk+xJ/hkaFn+m75cEXjTq/gS55y6p3OYGVe+Q+26Q+7c+Eu2st/w3yMJvyOIN7rD0dVL9OVm2dhnuq9xLVl8ga1Y+Cmt3k/VnyEY3PtTsILWnyOZ7/Gh8B0T/Itq5Hu3vkoYCD7QbvyAHnvKEpmzSfJEcemI5HPkrOfoxaVm2Ao6/SE6eJq33SdtzXnD6GDl7i5x7ZiW0l5ML18mljY9D3kFS8PITyNv3POn/2Cr8H7CTFH5IrnuwCu3B2wVQdFyA+YXcITdLn8T/YW+T4d+R4i2rIXdoNeJEfk2y9T5QlkvG9pHxa3xh4iuk/BMyafkamJJK7vqIVDwk0xP8ME7mCXLPXfL//hMh1Q=="
S = {"nu2":    (r"$\nu_2$",       2,  453.4,  454.9),
     "nu1":    (r"$\nu_1$",       3,  954.8,  954.3),
     "2nu2":   (r"$2\nu_2$",      4,  910.6,  916.0),
     "nu1nu2": (r"$\nu_1+\nu_2$", 7, 1405.1, 1406.4),
     "2nu1":   (r"$2\nu_1$",      5, 1903.8, 1903.1),
     "3nu1":   (r"$3\nu_1$",      6, 2851.9, 2852.2)}              # label, file index, cyclohexane-run shift (levels.py), gas-run shift
ORDER = list(S)
SOLVENT = [802, 1028, 1157, 1266, 1347, 1444]                       # cyclohexane bands marked * in the experimental figure
C = {"cyc": "#c0281c", "gas": "#1f5fa8", "exp": "0.55"}
plt.rcParams.update({"font.family": "serif", "mathtext.fontset": "cm", "font.size": 10,
                     "xtick.direction": "in", "ytick.direction": "in", "xtick.top": True, "ytick.right": True})

def load(folder, col):
    out = {}
    for k in ORDER:
        fn = os.path.join(folder, f"resRaman_1{S[k][1]}.txt"); d = np.loadtxt(fn, comments="#")
        if d.shape[1] < 6: sys.exit(f"{fn} has {d.shape[1]} columns: rerun spectra.jl (7-column patched version)")
        out[k] = (d[:, 0], d[:, 5] * (d[:, 0] - S[k][col]) ** 3)
    return out
P = {"cyc": load(CYC, 2), "gas": load(GAS, 3)}
SH = {"cyc": {k: S[k][2] for k in ORDER}, "gas": {k: S[k][3] for k in ORDER}}
I = {m: {k: float(np.interp(LASER, *P[m][k])) for k in ORDER} for m in P}
exp = np.frombuffer(zlib.decompress(base64.b64decode(EMBED)), dtype=np.float32).reshape(-1, 2)

def pv(x, x0, w): return ETA/(1+4*((x-x0)/w)**2) + (1-ETA)*np.exp(-4*np.log(2)*((x-x0)/w)**2)
rng = np.random.default_rng(SEED); x = np.arange(350, 2450, 1.0)
def trace(m):
    y = sum(I[m][k]/I[m]["nu1"] * pv(x, SH[m][k], FWHM) for k in ORDER)         # scaled so nu1 = 1
    if NOISE > 0: y = y + np.convolve(rng.normal(0, NOISE, x.size), np.ones(3)/3, "same") + 0.015
    return y

fig, ax = plt.subplots(figsize=(8.5, 4.6))
ax.fill_between(exp[:, 0], exp[:, 1], color=C["exp"], alpha=0.45, lw=0)
ax.plot(exp[:, 0], exp[:, 1], color="0.25", lw=0.9, label="Experiment: OClO in cyclohexane (Reid 2001, digitised)")
ax.plot(x, trace("gas"), color=C["gas"], lw=1.3, label="Model: gas phase")
ax.plot(x, trace("cyc"), color=C["cyc"], lw=1.6, label="Model: cyclohexane solvent")
for s in SOLVENT: ax.annotate("*", (s, np.interp(s, exp[:, 0], exp[:, 1]) + 0.05), ha="center", fontsize=11, color="0.25")
ax.annotate(r"$\nu_1$ (expt)", (938, 1.08), xytext=(938, 1.6), ha="center", fontsize=8, arrowprops=dict(arrowstyle="-", lw=0.6))
ax.annotate(r"$2\nu_1$ (expt)", (1874, 0.58), xytext=(1874, 1.1), ha="center", fontsize=8, arrowprops=dict(arrowstyle="-", lw=0.6))
for v, t in ((2190, r"$2\nu_3$"), (2319, r"$2\nu_1+\nu_2$")): ax.annotate(t + " (expt, weak)", (v, 0.06), xytext=(v, 0.5), ha="center", fontsize=7, rotation=90, va="bottom", arrowprops=dict(arrowstyle="-", lw=0.5, color="0.4"))
for k in ORDER:
    sh = SH["cyc"][k]
    if 350 < sh < 2450 and k != "nu1": ax.annotate(S[k][0], (sh, trace("cyc")[int(round(sh - 350))] + 0.05), ha="center", fontsize=9, color=C["cyc"])
ax.set_xlim(350, 2450); ax.set_ylim(-0.1, min(6.0, max(3.4, 1.1 * max(trace("cyc").max(), trace("gas").max())))); ax.set_xlabel(r"Raman shift (cm$^{-1}$)"); ax.set_ylabel(r"Intensity (scaled so $\nu_1$ = 1)")
ax.text(0.98, 0.95, f"{LASER_NM:.1f} nm", transform=ax.transAxes, ha="right", va="top")
ax.legend(frameon=False, fontsize=8.5, loc="upper right", bbox_to_anchor=(1, 0.90))
fig.tight_layout(rect=(0, 0.04, 1, 1))
fig.text(0.5, 0.01, r"* = cyclohexane solvent bands (not in the model). Model lines: %.0f cm$^{-1}$ FWHM" % FWHM + (", synthetic noise added for display only." if NOISE > 0 else "."), ha="center", fontsize=7.5, color="0.35")
fig.savefig("fig_cyclohexane_overlay.png", dpi=300)

L = []
L.append(f"Laser {LASER_NM:.1f} nm ({LASER:.0f} cm-1). Raw model intensities, relative to nu1 (nu1 = 1):")
for m in ("cyc", "gas"): L.append(f"  {'cyclohexane model' if m=='cyc' else 'gas-phase model':<18s} " + "  ".join(f"{S[k][0].strip('$')}={I[m][k]/I[m]['nu1']:.2f}" for k in ORDER))
L.append(f"nu1 position: cyclohexane model {SH['cyc']['nu1']:.1f}, gas model {SH['gas']['nu1']:.1f}, experiment 938 (digitised peak {exp[(exp[:,0]>915)&(exp[:,0]<960)][:,1].argmax() and exp[(exp[:,0]>915)&(exp[:,0]<960)][exp[(exp[:,0]>915)&(exp[:,0]<960)][:,1].argmax(),0]:.0f})")
open("cyclohexane_overlay_summary.txt", "w").write("\n".join(L) + "\n"); print("\n".join(L)); print("saved fig_cyclohexane_overlay.png")
