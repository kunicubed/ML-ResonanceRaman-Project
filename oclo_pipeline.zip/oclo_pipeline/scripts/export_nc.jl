# Julia: export WF.nc and eigenstates.nc to plain binary files for plotting in Python.
# usage:  julia export_nc.jl WF.nc eigenstates.nc
# writes: wf_dens.bin, wf_cf.bin, eig_re.bin, meta.txt   (Float32, column-major)
using NCDatasets

FRAME_FS = 10.0                                   # time between stored frames, fs (stride * dt)
SNAP_FS  = [0, 10, 20, 40, 80, 150, 300, 600]     # snapshot times to export, fs

wf_path, eig_path = ARGS[1], ARGS[2]

# put an array into (x, y, other) order by matching axis lengths to nx, ny
function to3(A, nx, ny)
    sz = size(A)
    ix = findfirst(==(nx), sz)
    iy = findfirst(i -> sz[i] == ny && i != ix, 1:length(sz))
    it = setdiff(1:length(sz), (ix, iy))
    A3 = ndims(A) == 2 ? reshape(A, size(A)..., 1) : A
    return permutedims(A3, (ix, iy, (length(it) == 0 ? 3 : it[1])))
end

open("meta.txt", "w") do meta
    ds = NCDataset(wf_path)
    println("variables in $wf_path: ", keys(ds))
    X = Float64.(ds["Xdim"][:]); Y = Float64.(ds["Ydim"][:])
    nx, ny = length(X), length(Y)
    println("WFRe size: ", size(ds["WFRe"]))
    re = to3(Float64.(Array(ds["WFRe"][:, :, :])), nx, ny)
    im = to3(Float64.(Array(ds["WFIm"][:, :, :])), nx, ny)
    nt = size(re, 3)
    idx = unique(clamp.(round.(Int, SNAP_FS ./ FRAME_FS) .+ 1, 1, nt))
    dens = re[:, :, idx] .^ 2 .+ im[:, :, idx] .^ 2
    open("wf_dens.bin", "w") do io; write(io, Float32.(dens)); end
    cf = hcat(Float64.(vec(ds["CFRe"][:])), Float64.(vec(ds["CFIm"][:])))
    open("wf_cf.bin", "w") do io; write(io, Float32.(cf)); end
    println(meta, "nx $nx\nny $ny\nnt $nt\nnsnap $(length(idx))\nncf $(size(cf,1))")
    println(meta, "snap_fs ", join((idx .- 1) .* FRAME_FS, " "))
    println(meta, "xmin $(minimum(X))\nxmax $(maximum(X))\nymin $(minimum(Y))\nymax $(maximum(Y))")
    close(ds)

    de = NCDataset(eig_path)
    println("variables in $eig_path: ", keys(de))
    println("eigenstate WFRe size: ", size(de["WFRe"]))
    ere = to3(Float64.(Array(de["WFRe"][:, :, :])), nx, ny)
    open("eig_re.bin", "w") do io; write(io, Float32.(ere)); end
    println(meta, "neig $(size(ere, 3))")
    println(meta, "energies ", join(Float64.(vec(de["energies"][:])), " "))
    close(de)
end
println("done: wf_dens.bin wf_cf.bin eig_re.bin meta.txt")
