Plot wavepacket snapshots, autocorrelation and eigenstates from the files written by export_nc.jl.
Optional: pot_excited.dat / pot_ground.dat in the same folder add potential contours."""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

WS, WB, HARTREE_CM = 964.53, 455.37, 219474.63
LABELS = [r"$(0,0)$", r"$\nu_2$", r"$\nu_1$", r"$2\nu_2$", r"$2\nu_1$", r"$3\nu_1$", r"$\nu_1+\nu_2$"]  # order of eigenstates.nc
XLIM, YLIM = (-4, 10), (-4, 6)          # plot window in dimensionless q
FRAME_FS = 10.0

plt.rcParams.update({"font.family": "serif", "mathtext.fontset": "cm", "font.size": 10,
                     "xtick.direction": "in", "ytick.direction": "in"})
meta = {}
for line in open("meta.txt"):
    k, *v = line.split(); meta[k] = v
nx, ny = int(meta["nx"][0]), int(meta["ny"][0])
xmin, xmax, ymin, ymax = (float(meta[k][0]) for k in ("xmin", "xmax", "ymin", "ymax"))
qs = np.linspace(xmin, xmax, nx) * np.sqrt(WS / HARTREE_CM)     # dimensionless
qb = np.linspace(ymin, ymax, ny) * np.sqrt(WB / HARTREE_CM)

def load3(fn, n):                       # Julia wrote column-major (x, y, n): x fastest
    a = np.fromfile(fn, dtype=np.float32).reshape(n, ny, nx)
    return a.transpose(0, 2, 1)         # -> (n, x, y)

def pot_contours(ax, fn, color, levels):
    if not os.path.exists(fn): return
    d = np.loadtxt(fn)
    X = np.unique(d[:, 0]) * np.sqrt(WS / HARTREE_CM); Y = np.unique(d[:, 1]) * np.sqrt(WB / HARTREE_CM)
    E = d[:, 2].reshape(X.size, Y.size) * HARTREE_CM
    E -= E.min() if "ground" in fn else 0
    ax.contour(X, Y, E.T, levels=levels, colors=color, linewidths=0.5, alpha=0.7)

# ---- wavepacket snapshots ----
ns = int(meta["nsnap"][0]); dens = load3("wf_dens.bin", ns); times = [float(t) for t in meta["snap_fs"]]
ncol = 4; nrow = int(np.ceil(ns / ncol))
fig, axs = plt.subplots(nrow, ncol, figsize=(3.0 * ncol, 2.5 * nrow), sharex=True, sharey=True, squeeze=False)
for ax, d, t in zip(axs.ravel(), dens, times):
    ax.pcolormesh(qs, qb, (d / d.max()).T, cmap="Reds", shading="auto", vmin=0, vmax=1)
    pot_contours(ax, "pot_excited.dat", "k", np.arange(24000, 60001, 6000))
    ax.set_xlim(*XLIM); ax.set_ylim(*YLIM); ax.text(0.04, 0.9, f"t = {t:.0f} fs", transform=ax.transAxes, fontsize=9)
for ax in axs.ravel()[ns:]: ax.axis("off")
for ax in axs[-1]: ax.set_xlabel(r"$q_s$")
for ax in axs[:, 0]: ax.set_ylabel(r"$q_b$")
fig.tight_layout(); fig.savefig("fig_wavepacket.png", dpi=300); plt.close(fig)

# ---- autocorrelation ----
ncf = int(meta["ncf"][0]); cf = np.fromfile("wf_cf.bin", dtype=np.float32).reshape(2, ncf).T
c = cf[:, 0] + 1j * cf[:, 1]; t = np.arange(ncf) * FRAME_FS
fig, ax = plt.subplots(figsize=(6, 3.2))
ax.plot(t, np.abs(c) / np.abs(c).max(), "k", lw=1.0)
ax.set_xlabel("t (fs)"); ax.set_ylabel(r"$|C(t)|$ (scaled)"); ax.set_xlim(0, min(t[-1], 1500))
fig.tight_layout(); fig.savefig("fig_autocorrelation.png", dpi=300); plt.close(fig)

# ---- eigenstates ----
ne = int(meta["neig"][0]); eig = load3("eig_re.bin", ne); en = [float(e) for e in meta["energies"]]
ncol = 4; nrow = int(np.ceil(ne / ncol))
fig, axs = plt.subplots(nrow, ncol, figsize=(3.0 * ncol, 2.5 * nrow), sharex=True, sharey=True, squeeze=False)
for k, ax in enumerate(axs.ravel()):
    if k >= ne: ax.axis("off"); continue
    v = eig[k]; v = v / np.abs(v).max()
    ax.pcolormesh(qs, qb, v.T, cmap="RdBu_r", shading="auto", vmin=-1, vmax=1)
    ax.set_xlim(-4, 4); ax.set_ylim(-4, 4)
    lab = LABELS[k] if k < len(LABELS) else f"state {k}"
    ax.text(0.04, 0.86, f"{lab}  {en[k] - en[0]:.0f} cm$^{{-1}}$" if k < len(en) else lab, transform=ax.transAxes, fontsize=9)
for ax in axs[-1]: ax.set_xlabel(r"$q_s$")
for ax in axs[:, 0]: ax.set_ylabel(r"$q_b$")
fig.tight_layout(); fig.savefig("fig_eigenstates.png", dpi=300); plt.close(fig)
print("saved fig_wavepacket.png fig_autocorrelation.png fig_eigenstates.png")
