# usage: python plot_regression.py [scan_results.csv]   (run in the folder with the csv)
import sys, numpy as np, matplotlib.pyplot as plt
from pathlib import Path
from sklearn.gaussian_process import GaussianProcessRegressor as GPR
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel
from sklearn.model_selection import KFold

HCM = 219474.63
f = sys.argv[1] if len(sys.argv) > 1 else "scan_results.csv"
X, E, MU = [], [], []
for line in Path(f).read_text().splitlines():
    p = line.split(",")
    try:
        X.append([float(p[2]), float(p[3])]); E.append([float(p[6]), float(p[7])]); MU.append(float(p[10]))
    except (ValueError, IndexError):
        continue
X, E, MU = map(np.array, (X, E, MU))
keep = ~((X[:, 0] > 10) & (X[:, 1] > 6)); X, E, MU = X[keep], E[keep], MU[keep]   # same cleaning as full.py
E = (E - E[:, 0].min()) * HCM
data = {"Ground (cm$^{-1}$)": E[:, 0], "Excited (cm$^{-1}$)": E[:, 1], "Dipole $\\mu_y$": MU}

def gp():
    k = C(1.0, (1e-3, 1e3))*RBF([3.0, 3.0], (0.3, 30.0)) + WhiteKernel(1e-8, (1e-12, 1e-4))
    return GPR(k, normalize_y=True, n_restarts_optimizer=5, random_state=0)

xs = np.linspace(X[:, 0].min(), X[:, 0].max(), 150); ys = np.linspace(X[:, 1].min(), X[:, 1].max(), 120)
G = np.array(np.meshgrid(xs, ys)).reshape(2, -1).T

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(3, 3, figsize=(11, 9.5), dpi=200)
for r, (name, y) in enumerate(data.items()):
    model = gp().fit(X, y)
    Z = model.predict(G).reshape(len(ys), len(xs))
    a = ax[r, 0]; cs = a.contourf(xs, ys, Z, 30, cmap="viridis"); fig.colorbar(cs, ax=a, label=name)
    a.scatter(X[:, 0], X[:, 1], s=5, c="w", edgecolors="k", lw=0.3); a.set_xlabel("$q_s$"); a.set_ylabel("$q_b$")
    # 1D cut along q_s through the point nearest the minimum in q_b
    a = ax[r, 1]; j = np.argmin(Z.min(axis=1)); yb = ys[np.argmin(Z.min(axis=1))] if r < 2 else ys[len(ys)//2]
    m = np.abs(X[:, 1] - X[np.argmin(np.abs(X[:, 1] - yb)), 1]) < 1e-6
    mu, sd = model.predict(np.c_[xs, np.full_like(xs, X[m, 1][0])], return_std=True)
    a.fill_between(xs, mu-2*sd, mu+2*sd, color="C0", alpha=0.25); a.plot(xs, mu, "C0"); a.plot(X[m, 0], y[m], "k.")
    a.set_xlabel("$q_s$"); a.set_ylabel(name); a.set_title(f"cut at $q_b$={X[m,1][0]:.2f} (±2σ)", fontsize=8)
    # cross-validated parity
    a = ax[r, 2]; pred = np.zeros_like(y)
    for tr, te in KFold(5, shuffle=True, random_state=0).split(X): pred[te] = gp().fit(X[tr], y[tr]).predict(X[te])
    a.plot(y, pred, "C1.", ms=4); lim = [min(y.min(), pred.min()), max(y.max(), pred.max())]; a.plot(lim, lim, "k--", lw=0.8)
    a.set_xlabel("TD-DFT"); a.set_ylabel("GP (5-fold CV)"); a.set_title(f"RMSE = {np.sqrt(np.mean((pred-y)**2)):.3g}", fontsize=8)
fig.tight_layout(); fig.savefig("regression.png"); print("saved regression.png")

# ---- 3D wireframe + projected contour (like the reference style), one panel per surface ----
fig3 = plt.figure(figsize=(14, 4.6), dpi=200)
xs3 = np.linspace(xs[0], xs[-1], 60); ys3 = np.linspace(ys[0], ys[-1], 45)
XX, YY = np.meshgrid(xs3, ys3); G3 = np.c_[XX.ravel(), YY.ravel()]
for k, (name, y) in enumerate(data.items()):
    Z = gp().fit(X, y).predict(G3).reshape(XX.shape)
    a = fig3.add_subplot(1, 3, k+1, projection="3d")
    zmin = Z.min() - 0.5*(Z.max()-Z.min())
    a.plot_wireframe(XX, YY, Z, rstride=3, cstride=3, color="#3b73b0", lw=0.7)
    a.contourf(XX, YY, Z, 8, zdir="z", offset=zmin, cmap="Blues_r", alpha=0.9)
    a.scatter(X[:, 0], X[:, 1], np.full(len(X), zmin), s=2, c="k", alpha=0.4)
    a.set_zlim(zmin, Z.max()); a.set_xlabel("$q_s$"); a.set_ylabel("$q_b$"); a.set_zlabel(name)
    a.view_init(elev=18, azim=-60)
    for ax_ in (a.xaxis, a.yaxis, a.zaxis): ax_.pane.set_facecolor((0.95, 0.95, 0.95, 1))
fig3.tight_layout(); fig3.savefig("regression_3d.png"); print("saved regression_3d.png")
