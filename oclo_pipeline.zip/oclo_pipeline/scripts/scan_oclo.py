import argparse
import os
import csv
import re
import subprocess
import sys
from pathlib import Path

import numpy as np

# ----------------------------------------------------------------------------
# SETTINGS - edit these
# ----------------------------------------------------------------------------
ORCA = os.environ.get("ORCA", "orca")          # full path to the orca executable
OPT_OUTPUT = "oclo_opt.out"               # B3LYP Opt+Freq output (ground state)
METHOD_LINE = "! UKS B3LYP D3BJ def2-TZVP TightSCF"
NROOTS = 6
CHARGE, MULT = 0, 2

MODE_BEND = 6                             # mode numbers as printed by ORCA
MODE_STRETCH = 7

# grid in dimensionless normal coordinates: (start, stop, number of points)
QS_GRID = (-3.0, 11.0, 21)                # symmetric stretch
QB_GRID = (-3.5, 7.0, 15)                 # bend

SCAN_DIR = "scan"
RESULTS = "scan_results.csv"
# ----------------------------------------------------------------------------

BOHR = 0.529177210903                     # angstrom per bohr
AMU = 1822.888486209                      # electron masses per amu
CM = 1.0 / 219474.6313632                 # hartree per cm^-1
EV = 1.0 / 27.211386245988                # hartree per eV


# ----------------------------------------------------------------------------
# Reading the ground-state optimisation output
# ----------------------------------------------------------------------------
def read_opt_output(path):
    """Return symbols, masses (amu), coordinates (bohr), frequencies, modes."""
    text = Path(path).read_text()
    if "ORCA TERMINATED NORMALLY" not in text:
        sys.exit(f"{path} did not terminate normally.")

    # last 'CARTESIAN COORDINATES (A.U.)' block: symbol, mass, x y z in bohr
    blocks = text.split("CARTESIAN COORDINATES (A.U.)")
    lines = blocks[-1].splitlines()
    symbols, masses, coords = [], [], []
    for line in lines[3:]:
        parts = line.split()
        if len(parts) != 8:
            break
        symbols.append(parts[1])
        masses.append(float(parts[4]))
        coords.append([float(v) for v in parts[5:8]])
    masses = np.array(masses)
    coords = np.array(coords)
    n3 = 3 * len(symbols)

    # frequencies
    freq_block = text.split("VIBRATIONAL FREQUENCIES")[-1]
    freqs = np.zeros(n3)
    for m in re.finditer(r"^\s*(\d+):\s+(-?\d+\.\d+)\s+cm\*\*-1", freq_block, re.M):
        freqs[int(m.group(1))] = float(m.group(2))

    # normal modes, printed in column blocks
    mode_block = text.split("NORMAL MODES")[-1].split("IR SPECTRUM")[0]
    modes = np.zeros((n3, n3))            # modes[row, mode]
    cols = None
    for line in mode_block.splitlines():
        parts = line.split()
        if not parts:
            continue
        if all(re.fullmatch(r"\d+", p) for p in parts):
            cols = [int(p) for p in parts]
        elif cols and re.fullmatch(r"\d+", parts[0]) and len(parts) == len(cols) + 1:
            row = int(parts[0])
            for c, v in zip(cols, parts[1:]):
                modes[row, c] = float(v)
    return symbols, masses, coords, freqs, modes


def mass_weighted_mode(modes, masses, k):
    """ORCA prints Cartesian displacements; convert to a unit mass-weighted vector."""
    m3 = np.repeat(masses, 3)
    v = modes[:, k] * np.sqrt(m3)
    return v / np.linalg.norm(v)


def bond_and_angle(coords):
    """Cl-O distance (angstrom) and O-Cl-O angle (degrees); atom 0 is Cl."""
    a = coords[1] - coords[0]
    b = coords[2] - coords[0]
    r = 0.5 * (np.linalg.norm(a) + np.linalg.norm(b)) * BOHR
    ang = np.degrees(np.arccos(a @ b / np.linalg.norm(a) / np.linalg.norm(b)))
    return r, ang


class Molecule:
    def __init__(self, path):
        (self.symbols, self.masses, self.x0,
         self.freqs, modes) = read_opt_output(path)
        m3 = np.repeat(self.masses * AMU, 3)
        self.disp = {}
        r0, a0 = bond_and_angle(self.x0)
        for name, k in (("s", MODE_STRETCH), ("b", MODE_BEND)):
            omega = self.freqs[k] * CM
            lmw = mass_weighted_mode(modes, self.masses, k)
            d = (lmw / np.sqrt(m3 * omega)).reshape(-1, 3)   # bohr per unit q
            r1, a1 = bond_and_angle(self.x0 + 0.1 * d)
            if name == "s" and r1 < r0:      # positive q_s must lengthen the bond
                d = -d
            if name == "b" and a1 > a0:      # positive q_b must close the angle
                d = -d
            self.disp[name] = d

    def geometry(self, qs, qb):
        return self.x0 + qs * self.disp["s"] + qb * self.disp["b"]


# ----------------------------------------------------------------------------
# ORCA input / output
# ----------------------------------------------------------------------------
def write_input(path, symbols, coords):
    lines = [METHOD_LINE, "", "%tddft", f"  nroots {NROOTS}", "end", "",
             f"* xyz {CHARGE} {MULT}"]
    for s, c in zip(symbols, coords * BOHR):
        lines.append(f"{s:2s} {c[0]:16.10f} {c[1]:16.10f} {c[2]:16.10f}")
    lines += ["*", "", ""]
    Path(path).write_text("\n".join(lines))


def parse_output(path):
    """Return dict of results, or None if the job is missing or failed."""
    p = Path(path)
    if not p.exists():
        return None
    text = p.read_text()
    if "ORCA TERMINATED NORMALLY" not in text:
        return None

    # FINAL SINGLE POINT ENERGY = ground state (with dispersion and any solvation)
    # plus the excitation energy of the root ORCA reports in DE(CIS).
    e_final = float(re.findall(r"FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)", text)[-1])
    de_cis = float(re.findall(r"DE\(CIS\)\s+=\s+(-?\d+\.\d+)", text)[-1])
    e_ground = e_final - de_cis

    block = text.split("ABSORPTION SPECTRUM VIA TRANSITION ELECTRIC DIPOLE MOMENTS")[1]
    block = block.split("ABSORPTION SPECTRUM VIA TRANSITION VELOCITY")[0]
    states = []
    pat = (r"0-\dA\s+->\s+(\d+)-(\d)A\s+(\d+\.\d+)\s+\S+\s+\S+\s+(\d+\.\d+)"
           r"\s+\S+\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)")
    for m in re.finditer(pat, block):
        root, mult = int(m.group(1)), int(m.group(2))
        states.append(dict(root=root, mult=mult, ev=float(m.group(3)),
                           fosc=float(m.group(4)), dx=float(m.group(5)),
                           dy=float(m.group(6)), dz=float(m.group(7))))
    doublets = [s for s in states if s["mult"] == MULT]
    if not doublets:
        return None
    # bright state = largest y-component of the transition dipole
    ranked = sorted(doublets, key=lambda s: abs(s["dy"]), reverse=True)
    best = ranked[0]
    runner_up = abs(ranked[1]["dy"]) if len(ranked) > 1 else 0.0
    return dict(e_ground=e_ground,
                e_bright=e_ground + best["ev"] * EV,
                exc_ev=best["ev"], fosc=best["fosc"], mu_y=abs(best["dy"]),
                root=best["root"], runner_up_mu_y=runner_up)


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="print grid, run nothing")
    ap.add_argument("--collect", action="store_true", help="only rebuild the CSV")
    ap.add_argument("--solvent", default=None,
                    help="implicit solvent name for CPCM, e.g. cyclohexane, water, "
                         "chloroform. Uses its own folder and results file.")
    ap.add_argument("--test", action="store_true",
                    help="run only the equilibrium geometry and print the result")
    args = ap.parse_args()

    global METHOD_LINE, SCAN_DIR, RESULTS
    if args.solvent:
        METHOD_LINE += f" CPCM({args.solvent})"
        SCAN_DIR = f"scan_{args.solvent}"
        RESULTS = f"scan_results_{args.solvent}.csv"
    print(f"Method: {METHOD_LINE}")
    print(f"Folder: {SCAN_DIR}   results: {RESULTS}")

    mol = Molecule(OPT_OUTPUT)
    qs_values = np.linspace(*QS_GRID)
    qb_values = np.linspace(*QB_GRID)
    r0, a0 = bond_and_angle(mol.x0)

    print(f"Equilibrium: r = {r0:.4f} A, angle = {a0:.2f} deg")
    print(f"Stretch mode {MODE_STRETCH}: {mol.freqs[MODE_STRETCH]:.1f} cm-1,"
          f" bend mode {MODE_BEND}: {mol.freqs[MODE_BEND]:.1f} cm-1")
    print(f"Grid: {len(qs_values)} x {len(qb_values)} = "
          f"{len(qs_values) * len(qb_values)} points")
    corners = [bond_and_angle(mol.geometry(s, b))
               for s in (qs_values[0], qs_values[-1])
               for b in (qb_values[0], qb_values[-1])]
    print(f"Bond length range: {min(c[0] for c in corners):.3f} to "
          f"{max(c[0] for c in corners):.3f} A")
    print(f"Angle range:       {min(c[1] for c in corners):.1f} to "
          f"{max(c[1] for c in corners):.1f} deg")
    for name, q in (("pure stretch q_s=1", (1, 0)), ("pure bend    q_b=1", (0, 1))):
        r, a = bond_and_angle(mol.geometry(*q))
        print(f"  {name}: r changes by {r - r0:+.4f} A, angle by {a - a0:+.2f} deg")
    if args.check:
        return

    scan = Path(SCAN_DIR)
    scan.mkdir(exist_ok=True)

    if args.test:
        folder = scan / "test_equilibrium"
        folder.mkdir(exist_ok=True)
        write_input(folder / "pt.inp", mol.symbols, mol.geometry(0.0, 0.0))
        print("Running one test point at the equilibrium geometry...")
        with open(folder / "pt.out", "w") as fh:
            subprocess.run([ORCA, "pt.inp"], cwd=folder, stdout=fh,
                           stderr=subprocess.STDOUT)
        res = parse_output(folder / "pt.out")
        if res is None:
            print(f"Test FAILED - open {folder / 'pt.out'} and read the last lines.")
        else:
            print("Test OK:")
            for k, v in res.items():
                print(f"  {k:16s} {v}")
        return
    rows, failed = [], []
    total = len(qs_values) * len(qb_values)
    n = 0
    for i, qs in enumerate(qs_values):
        for j, qb in enumerate(qb_values):
            n += 1
            folder = scan / f"pt_{i:02d}_{j:02d}"
            out = folder / "pt.out"
            geom = mol.geometry(qs, qb)
            res = parse_output(out)
            if res is None and not args.collect:
                folder.mkdir(exist_ok=True)
                write_input(folder / "pt.inp", mol.symbols, geom)
                print(f"[{n}/{total}] q_s={qs:+.3f} q_b={qb:+.3f} running...",
                      flush=True)
                with open(out, "w") as fh:
                    subprocess.run([ORCA, "pt.inp"], cwd=folder, stdout=fh,
                                   stderr=subprocess.STDOUT)
                res = parse_output(out)
            if res is None:
                failed.append((i, j, qs, qb))
                continue
            r, a = bond_and_angle(geom)
            rows.append(dict(i=i, j=j, q_s=qs, q_b=qb, r_ClO=r, angle=a, **res))

    fields = ["i", "j", "q_s", "q_b", "r_ClO", "angle", "e_ground", "e_bright",
              "exc_ev", "fosc", "mu_y", "root", "runner_up_mu_y"]
    with open(RESULTS, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"\nWrote {len(rows)} points to {RESULTS}")
    if failed:
        print(f"{len(failed)} points missing or failed:")
        for i, j, qs, qb in failed:
            print(f"  pt_{i:02d}_{j:02d}  q_s={qs:+.3f} q_b={qb:+.3f}")
    ambiguous = [r for r in rows if r["runner_up_mu_y"] > 0.3 * r["mu_y"]]
    if ambiguous:
        print(f"{len(ambiguous)} points where a second state also has a sizeable "
              "y-dipole (possible state mixing) - inspect these:")
        for r in ambiguous:
            print(f"  pt_{r['i']:02d}_{r['j']:02d}")


if __name__ == "__main__":
    main()
