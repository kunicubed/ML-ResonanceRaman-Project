#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export ORCA="${ORCA:-$HOME/orca/orca}"
if [ -z "${JULIA:-}" ]; then
  if command -v julia >/dev/null 2>&1; then JULIA=julia; else JULIA="$HOME/.juliaup/bin/julia"; fi
fi
export JULIA
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
PYTHON="${PYTHON:-python3}"
if command -v caffeinate >/dev/null 2>&1; then
  exec caffeinate -i "$PYTHON" pipeline.py "$@"
fi
exec "$PYTHON" pipeline.py "$@"
