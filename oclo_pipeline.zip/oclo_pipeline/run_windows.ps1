$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
if (-not $env:ORCA)  { $env:ORCA = "C:\ORCA\orca.exe" }
if (-not $env:JULIA) { $env:JULIA = "julia" }
$env:OMP_NUM_THREADS = "1"
$env:PYTHONUTF8 = "1"
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 pipeline.py @args
} else {
    & python pipeline.py @args
}
exit $LASTEXITCODE
