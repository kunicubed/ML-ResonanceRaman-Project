#!/usr/bin/env python3
import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "scripts"
QD = ROOT / "qd"
INPUTS = ROOT / "inputs"
RUNS = ROOT / "runs"

ORCA = os.environ.get("ORCA", "orca")
JULIA = os.environ.get("JULIA", "julia")
PY = sys.executable

GROUND_YML = "ground.yml"
EXCITED_YML = "excited.yml"
GROUND_POT = "pot_ground.dat"
EXCITED_POT = "pot_excited.dat"
SPECTRA_JL = "spectra_nu3.jl"
FINAL_STATES = [2, 3, 4, 5, 6, 7]
SOLVENTS = ["cyclohexane"]
GEOMETRY = """Cl     0.0000000000    -0.0000020993    -0.3002991405
O      0.0000000000     1.2362279339     1.0925811282
O      0.0000000000    -1.2362234794     1.0925792169"""
OPT_METHOD = "! UKS B3LYP D3BJ def2-TZVP TightSCF TightOpt Freq"

STAGES = ["opt", "scan", "fit", "levels", "ground", "excited", "spectra",
          "plots", "wf", "regression", "compare"]

DRY = False
FORCE = False


def log(msg):
    print(f"\n=== {msg}", flush=True)


def run(cmd, cwd, logfile=None, stdout_to=None):
    cmd = [str(c) for c in cmd]
    print(f">>> [{Path(cwd).relative_to(ROOT) if Path(cwd).is_relative_to(ROOT) else cwd}] {' '.join(cmd)}", flush=True)
    if DRY:
        return
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", MPLBACKEND="Agg", PYTHONWARNINGS="ignore")
    if stdout_to:
        with open(stdout_to, "w", encoding="utf-8", errors="replace") as fh:
            rc = subprocess.run(cmd, cwd=cwd, env=env, stdout=fh, stderr=subprocess.STDOUT).returncode
    else:
        lf = open(logfile, "w", encoding="utf-8", errors="replace") if logfile else None
        proc = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, bufsize=0)
        for chunk in iter(lambda: proc.stdout.read(1024), b""):
            text = chunk.decode("utf-8", errors="replace")
            sys.stdout.write(text)
            sys.stdout.flush()
            if lf:
                lf.write(text)
        proc.wait()
        rc = proc.returncode
        if lf:
            lf.close()
    if rc != 0:
        sys.exit(f"ERROR: command failed (exit {rc}): {' '.join(cmd)}")


def need(*paths):
    missing = [str(p) for p in paths if not Path(p).exists()]
    if missing and not DRY:
        sys.exit("ERROR: missing " + ", ".join(missing))


def julia(cwd, script, *args):
    script = Path(script)
    need(script)
    run([JULIA, script, *args], cwd, Path(cwd) / f"{script.stem}.log")


def py(cwd, script, *args, logfile=None, stdout_to=None):
    need(SCRIPTS / script)
    run([PY, SCRIPTS / script, *args], cwd, logfile, stdout_to)


def fresh(path):
    if path.exists() and not DRY:
        shutil.rmtree(path)
    if not DRY:
        path.mkdir(parents=True)


def put(src, dst):
    need(src)
    if not DRY:
        shutil.copy(src, dst)


def finished(path, text="ORCA TERMINATED NORMALLY"):
    p = Path(path)
    return p.exists() and text in p.read_text(errors="replace")


class Run:
    def __init__(self, tag):
        self.tag = tag
        self.solvent = None if tag == "gas" else tag
        self.dir = RUNS / tag
        self.fit = self.dir / "fit"
        self.ground = self.dir / "ground"
        self.excited = self.dir / "excited"
        self.wf = self.dir / "wf"
        self.figs = self.dir / "figures"
        self.csv = "scan_results.csv" if not self.solvent else f"scan_results_{self.solvent}.csv"
        for d in (self.fit, self.ground, self.excited, self.wf, self.figs):
            if not DRY:
                d.mkdir(parents=True, exist_ok=True)

    def yml(self, name):
        alt = INPUTS / name.replace(".yml", f"_{self.tag}.yml")
        return alt if alt.exists() else INPUTS / name

    def opt(self):
        out = RUNS / "common" / "oclo_opt.out"
        if finished(out) and not FORCE:
            print("opt: done")
            return
        if not DRY:
            out.parent.mkdir(parents=True, exist_ok=True)
        inp = out.parent / "oclo_opt.inp"
        if not DRY:
            inp.write_text(f"{OPT_METHOD}\n\n* xyz 0 2\n{GEOMETRY}\n*\n")
        run([ORCA, inp.name], out.parent, stdout_to=out)
        if not DRY and not finished(out):
            sys.exit(f"ERROR: optimisation did not finish, see {out}")

    def scan(self):
        if (self.fit / self.csv).exists() and not FORCE:
            print("scan: done")
            return
        need(RUNS / "common" / "oclo_opt.out")
        put(RUNS / "common" / "oclo_opt.out", self.fit / "oclo_opt.out")
        args = ["--solvent", self.solvent] if self.solvent else []
        py(self.fit, "scan_oclo.py", *args, logfile=self.fit / "scan.log")

    def fit_gp(self):
        if all((self.fit / f).exists() for f in (GROUND_POT, EXCITED_POT, "dipole.dat")) and not FORCE:
            print("fit: done")
            return
        need(self.fit / self.csv)
        py(self.fit, "gaussian.py", self.csv, logfile=self.fit / "gaussian.log")

    def levels(self):
        need(self.fit / GROUND_POT)
        py(self.fit, "levels.py", stdout_to=self.fit / "levels.txt")
        if not DRY:
            print((self.fit / "levels.txt").read_text())

    def ground_state(self):
        if all((self.ground / f).exists() for f in ("initWF.nc", "eigenstates.nc")) and not FORCE:
            print("ground: done")
            return
        fresh(self.ground)
        put(self.yml(GROUND_YML), self.ground / GROUND_YML)
        put(self.fit / GROUND_POT, self.ground / GROUND_POT)
        for s in ("interpolate.jl", "qd-engine.jl", "eigenstates.jl"):
            julia(self.ground, QD / s, GROUND_YML)
        need(self.ground / "initWF.nc", self.ground / "eigenstates.nc")

    def excited_state(self):
        if (self.excited / "WF.nc").exists() and not FORCE:
            print("excited: done")
            return
        yml = self.yml(EXCITED_YML)
        need(yml)
        if not DRY:
            text = yml.read_text()
            if re.search(r"^\s*imagT:", text, re.M):
                sys.exit(f"ERROR: {yml} still has an imagT block")
            if "nu3" not in text:
                print("WARNING: no nu3 block in the excited yml, the nu3 correction will not be applied")
        fresh(self.excited)
        put(yml, self.excited / EXCITED_YML)
        put(self.fit / EXCITED_POT, self.excited / EXCITED_POT)
        put(self.ground / "initWF.nc", self.excited / "initWF.nc")
        put(self.ground / "eigenstates.nc", self.excited / "eigenstates.nc")
        julia(self.excited, QD / "interpolate.jl", EXCITED_YML)
        julia(self.excited, QD / "qd-engine.jl", EXCITED_YML)
        need(self.excited / "WF.nc")

    def spectra(self):
        if all((self.excited / f"resRaman_1{n}.txt").exists() for n in FINAL_STATES) and not FORCE:
            print("spectra: done")
            return
        need(self.excited / "WF.nc")
        if not DRY:
            text = (self.excited / EXCITED_YML).read_text()
            states = "[" + ", ".join(str(n) for n in FINAL_STATES) + "]"
            new, k = re.subn(r"^(\s*finalstate:).*$", rf"\1 {states}", text, flags=re.M)
            if k != 1:
                sys.exit("ERROR: the excited yml needs exactly one 'finalstate:' line")
            (self.excited / "spectra.yml").write_text(new)
        julia(self.excited, SCRIPTS / SPECTRA_JL, "spectra.yml")

    def plots(self):
        d = self.excited
        need(d / f"resRaman_1{FINAL_STATES[0]}.txt")
        py(d, "ramanplot.py")
        py(d, "plot_profiles.py")
        py(d, "make_figures.py")
        spec = sorted(d.glob("spectrum_*.txt")) if not DRY else []
        if spec:
            pick = next((s for s in spec if s.name == "spectrum_550fs.txt"), spec[0])
            py(d, "plot_abs.py", pick.name, "absorption.png")
        self.collect(d)

    def waves(self):
        need(self.excited / "WF.nc", self.excited / "eigenstates.nc")
        put(self.fit / GROUND_POT, self.wf / GROUND_POT)
        put(self.fit / EXCITED_POT, self.wf / EXCITED_POT)
        julia(self.wf, SCRIPTS / "export_nc.jl", self.excited / "WF.nc", self.excited / "eigenstates.nc")
        py(self.wf, "plot_wf.py")
        self.collect(self.wf)

    def regression(self):
        need(self.fit / self.csv)
        py(self.fit, "plot_regression.py", self.csv)
        self.collect(self.fit)

    def collect(self, src):
        if DRY:
            return
        for png in Path(src).glob("*.png"):
            shutil.copy(png, self.figs / png.name)


def compare():
    log("compare: cyclohexane vs gas vs experiment")
    cyc, gas = Run("cyclohexane"), Run("gas")
    out = RUNS / "compare"
    if not DRY:
        out.mkdir(parents=True, exist_ok=True)
    py(out, "compare_cyclohexane.py", cyc.excited, gas.excited)


def preflight(stages, tags):
    if DRY:
        return
    for mod in ("numpy", "scipy", "sklearn", "matplotlib"):
        try:
            __import__(mod)
        except ImportError:
            sys.exit(f"ERROR: python module '{mod}' missing (run with --setup)")
    if any(s in stages for s in ("ground", "excited", "spectra", "wf")) and not shutil.which(JULIA):
        sys.exit(f"ERROR: julia not found ('{JULIA}'); set JULIA to the executable")
    if any(s in stages for s in ("opt", "scan")) and not (shutil.which(ORCA) or Path(ORCA).exists()):
        sys.exit(f"ERROR: ORCA not found ('{ORCA}'); set ORCA to the executable")
    for t in tags:
        r = Run(t)
        if any(s in stages for s in ("ground", "excited")):
            need(r.yml(GROUND_YML), r.yml(EXCITED_YML), QD / "interpolate.jl", QD / "qd-engine.jl", QD / "eigenstates.jl")


def setup():
    run([PY, "-m", "pip", "install", "numpy", "scipy", "scikit-learn", "matplotlib"], ROOT)
    pk = '["NCDatasets","FFTW","YAML","ArgParse"]'
    run([JULIA, "-e", f"using Pkg; Pkg.add({pk})"], ROOT)


def main():
    global DRY, FORCE, FINAL_STATES
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", nargs="+", default=["gas"], help="gas and/or solvent names, e.g. gas cyclohexane")
    ap.add_argument("--stages", nargs="+", choices=STAGES, help="run only these stages")
    ap.add_argument("--from", dest="start", choices=STAGES, help="run from this stage onwards")
    ap.add_argument("--final-states", nargs="+", type=int, default=FINAL_STATES)
    ap.add_argument("--force", action="store_true", help="redo stages whose outputs already exist")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--setup", action="store_true", help="install python and julia packages, then exit")
    a = ap.parse_args()
    DRY, FORCE, FINAL_STATES = a.dry_run, a.force, a.final_states

    if a.setup:
        setup()
        return

    stages = a.stages or (STAGES[STAGES.index(a.start):] if a.start else STAGES)
    if "compare" in stages and not {"gas", "cyclohexane"} <= set(a.runs):
        stages = [s for s in stages if s != "compare"]
    preflight(stages, a.runs)

    for tag in a.runs:
        r = Run(tag)
        table = {"opt": r.opt, "scan": r.scan, "fit": r.fit_gp, "levels": r.levels,
                 "ground": r.ground_state, "excited": r.excited_state, "spectra": r.spectra,
                 "plots": r.plots, "wf": r.waves, "regression": r.regression}
        for s in stages:
            if s in table:
                log(f"{tag}: {s}")
                table[s]()
    if "compare" in stages:
        compare()
    log("done")


if __name__ == "__main__":
    main()
